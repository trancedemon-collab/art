(() => {
  const injectStyles = () => {
    if (document.getElementById('yt-perf-booster')) return;
    const style = document.createElement('style');
    style.id = 'yt-perf-booster';
    style.textContent = `
      /* Disable Ambient Glow and Background Canvases */
      #cinematics, #cinematics-container, ytd-cinematics,
      canvas.ytp-ambient-canvas, .ytp-chrome-glow {
        display: none !important;
        visibility: hidden !important;
      }

      /* Kill non-essential UI transitions & animations */
      *, *::before, *::after {
        animation: none !important;
        transition: none !important;
        backdrop-filter: none !important;
        -webkit-backdrop-filter: none !important;
        box-shadow: none !important;
        text-shadow: none !important;
      }

      /* Disable inline hover video previews */
      #inline-preview-player, ytd-video-preview {
        display: none !important;
      }

      /* Remove dynamic button glints & touch feedback layers */
      yt-spec-touch-feedback-shape,
      .yt-spec-touch-feedback-shape__fill,
      .yt-spec-touch-feedback-shape__stroke {
        display: none !important;
      }
    `;
    (document.head || document.documentElement).appendChild(style);
  };

  const removeAmbientNodes = () => {
    document.querySelectorAll('#cinematics, ytd-cinematics, .ytp-ambient-canvas').forEach(el => el.remove());
  };

  injectStyles();

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => {
      injectStyles();
      removeAmbientNodes();
    });
  } else {
    removeAmbientNodes();
  }

  const observer = new MutationObserver(() => removeAmbientNodes());
  observer.observe(document.documentElement, { childList: true, subtree: true });
})();